
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
}

function initActiveNavLink() {
    const sections = document.querySelectorAll('section[id], div[id]');
    const navLinks = document.querySelectorAll('.navbar a');

    const observer = new IntersectionObserver(
        entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    /* remove "active" de todos os links */
                    navLinks.forEach(link => link.classList.remove('active'));

                    const activeLink = document.querySelector(
                        `.navbar a[href="#${entry.target.id}"]`
                    );
                    if (activeLink) activeLink.classList.add('active');
                }
            });
        },
        {
           
            threshold: 0.3,
         
            rootMargin: '-90px 0px 0px 0px'
        }
    );

    sections.forEach(section => observer.observe(section));
}


function initCardAnimations() {
    const cards = document.querySelectorAll(
        '.servico-card, .info-card, .menu .content, .homer-container-image'
    );

    /* estilo inicial: invisível e deslocado para baixo */
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(40px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });

    const observer = new IntersectionObserver(
        entries => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    /* delay escalonado: cada card aparece 100ms depois do anterior */
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, index * 100);

                    /* para de observar após animar (não repete) */
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15 }
    );

    cards.forEach(card => observer.observe(card));
}

function initHeaderScroll() {
    const header = document.querySelector('.header');

    window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
            header.style.boxShadow = '0 4px 40px rgba(180, 120, 80, 0.15)';
        } else {
            header.style.boxShadow = '0 2px 30px rgba(180, 120, 80, 0.08)';
        }
    });
}


function initFooterYear() {
    const footer = document.querySelector('.footer p');
    if (footer) {
        footer.innerHTML = footer.innerHTML.replace(
            /\d{4}/,
            new Date().getFullYear()
        );
    }
}


document.addEventListener('DOMContentLoaded', () => {
    initSmoothScroll();
    initActiveNavLink();
    initCardAnimations();
    initHeaderScroll();
    initFooterYear();
});
